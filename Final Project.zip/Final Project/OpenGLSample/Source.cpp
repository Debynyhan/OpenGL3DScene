﻿/*
Debynyhan Banks
CS 330 Comp Graphics and Visualization
12-10-23
7-1: Final Project
Professor Bishop
This code generate accurate representations of three-
dimensional objects using application programming interfaces
libraries and computer graphics development best practices.
It also demostrate interactive graphics applications that respond to input devices.
*/


// Libraries
#include <GL/glew.h> // OpenGl Extension Wrangler Library
#include <GLFW/glfw3.h> // Graphics Library Framework
#include <iostream> // Standard I/O
#include <vector> // Standard vector Library
#include <glm/glm.hpp> // GLM (OpenGL Mathematics)
#include <glm/gtc/matrix_transform.hpp> // GLM transformation
#include <glm/gtc/type_ptr.hpp> // GLM type pointers
#include "camera.h"



#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <string>
#include <map>

struct Vertex {
    glm::vec3 position;

    glm::vec2 texCoords;
    glm::vec3 normals;

    Vertex(const glm::vec3& pos, const glm::vec2& tex, const glm::vec3& norm)
        : position(pos), texCoords(tex), normals(norm) {}


};

struct CylinderParams {
    std::vector<Vertex> vertices;
    std::vector<unsigned int> indices;
    float height;
    float radius;
    int numberOfSides;

    CylinderParams(float h, float r, int sides)
        : height(h), radius(r), numberOfSides(sides) {
        generateCylinderMeshData();
    }

private:
    void generateCylinderMeshData() {
        // Clear existing data
        vertices.clear();
        indices.clear();

        const float M_PI = 3.14159265359f;
        float angleIncrement = 2 * M_PI / numberOfSides;

        // Center vertices for the top and bottom circle
        vertices.emplace_back(glm::vec3(0, height / 2, 0), glm::vec2(0.5f, 1.0f), glm::vec3(0, 1, 0)); // Top center
        vertices.emplace_back(glm::vec3(0, -height / 2, 0), glm::vec2(0.5f, 0.0f), glm::vec3(0, -1, 0)); // Bottom center

        // Generate vertices fro the top and bottom circle
        for (int i = 0; i < numberOfSides; ++i) {
            float angle = i * angleIncrement;
            float x = radius * cos(angle);
            float z = radius * sin(angle);
            glm::vec3 normal = glm::normalize(glm::vec3(x, 0, z));

            // Top vertex (normal points upwards)
            vertices.emplace_back(glm::vec3(x, height / 2, z), glm::vec2(angle / (2 * M_PI), 1.0), glm::vec3(0, 1, 0));

            // Bottom vertex (normal points upwards)
            vertices.emplace_back(glm::vec3(x, -height / 2, z), glm::vec2(angle / (2 * M_PI), 0.0), glm::vec3(0, 1, 0));


        }

        // Create indices for the top and bottom circle
        for (int i = 0; i < numberOfSides; ++i) {
            int nextIndex = (i + 1) % numberOfSides;
            int topVertex = 2 + i * 2;
            int bottomVertex = 3 + i * 2;

            // Top face
            indices.push_back(0);
            indices.push_back(topVertex);
            indices.push_back(2 + nextIndex * 2); // Center vertex of the topcircle

             // Bottom face
            indices.push_back(i * 2 + 1);
            indices.push_back(nextIndex * 2 + 1);
            indices.push_back(numberOfSides * 2 + 1); // Center vertex of the bottom circle
        }

        // Generate for the top and bottom circle
        for (int i = 0; i < numberOfSides; ++i) {
            int nextIndex = (i + 1) % numberOfSides;

            // Vertices for the side faces
            int topVertex1 = 2 + i * 2;
            int bottomVertex1 = 3 + i * 2;
            int topVertex2 = 2 + nextIndex * 2;
            int bottomVertex2 = 3 + nextIndex * 2;

            // Top face
            indices.push_back(topVertex1);
            indices.push_back(bottomVertex1);
            indices.push_back(topVertex2);

            indices.push_back(bottomVertex1);
            indices.push_back(bottomVertex2);
            indices.push_back(topVertex2);

        }
    }
};


struct TextureHandler {
    GLuint textureId;

    glm::vec2 uvScale = glm::vec2(1.0f, 1.0f);

    TextureHandler() {

    }

    TextureHandler(const char* filename) : textureId(0) {
        if (!createTexture(filename)) {
            std::cerr << "Failed to load texture: " << filename << std::endl;
        }
    }

    // Destructor
    ~TextureHandler() {
        glDeleteTextures(1, &textureId);
    }

    // Mehod to activate and bind texture
    void activateAndBind(GLenum textureUnit) const {
        glActiveTexture(textureUnit);
        glBindTexture(GL_TEXTURE_2D, textureId);
    }

    // Method to scale texture coordinates
    void scaleTexture(float scaleFactor) {
        uvScale *= scaleFactor;
        // Ensure scaleFactor is not zero to avoid divsion by zero
    }

    // Method to set uniform in shader
    void setScaleUniform(GLuint shaderProgram, const char* uniformName) {

        glUniform2fv(glGetUniformLocation(shaderProgram, uniformName), 1, glm::value_ptr(uvScale));
    }


    bool createTexture(const char* filename) {
        int width, height, channels;
        unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
        if (image) {
            flipImageVertically(image, width, height, channels);

            glGenTextures(1, &textureId);
            glBindTexture(GL_TEXTURE_2D, textureId);

            // set the texture wrapping and filtering parameters
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

            // Set texture format
            if (channels == 3) {
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
            }
            else if (channels == 4) {
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
            }
            else {
                std::cout << "Not implemented to handle image with " << channels << " channels " << std::endl;
                return false;
            }

         

            glGenerateMipmap(GL_TEXTURE_2D);
            stbi_image_free(image);
            glBindTexture(GL_TEXTURE_2D, 0); // Unbind texture

            return true;
        }

        return false; // Error loading the image
    }

    void flipImageVertically(unsigned char* image, int width, int height, int channels) {
        for (int j = 0; j < height / 2; ++j) {
            int index1 = j * width * channels;
            int index2 = (height - 1 - j) * width * channels;
            for (int i = width * channels; i > 0; --i) {
                unsigned char tmp = image[index1];
                image[index1] = image[index2];
                image[index2] = tmp;
                ++index1;
                ++index2;
            }
        }
    }
};

struct MouseHandler {

    glm::vec2 lastMousePos;

    bool firstMouse;
    float sensitivity;

    MouseHandler()
        : lastMousePos(800.0f / 2.0f, 600.0f / 2.0f), firstMouse(true), sensitivity(0.1f) {}

    void updateMousePosition(GLFWwindow* window, Camera& camera, float deltaTime) {

        double mouseX, mouseY;

        glfwGetCursorPos(window, &mouseX, &mouseY);

        if (firstMouse) {
            lastMousePos.x = mouseX;
            lastMousePos.y = mouseY;
            firstMouse = false;

        }

        // Compute offset
        float xoffset = (mouseX - lastMousePos.x) * sensitivity;
        float yoffset = (lastMousePos.y - mouseY) * sensitivity;

        lastMousePos.x = mouseX;
        lastMousePos.y = mouseY;

        camera.ProcessMouseMovement(xoffset, yoffset);
    }

    static void updateScroll(GLFWwindow* window, double xoffset, double yoffset) {
        Camera* camera = static_cast<Camera*>(glfwGetWindowUserPointer(window));
        if (camera) {
            camera->ProcessMouseScroll(static_cast<float>(yoffset));
        }
    }
};

struct AppContext {
    Camera* camera;
    MouseHandler* mouseHandler;
    bool isPerspective = true; // Default to perspective view
    AppContext(Camera* cam, MouseHandler* mouse) : camera(cam), mouseHandler(mouse) {}


};

struct Transform {
    glm::vec3 position;
    glm::vec3 rotation;
    glm::vec3 scale;

    Transform(const glm::vec3& pos = glm::vec3(0.0f),
        const glm::vec3& rot = glm::vec3(0.0f),
        const glm::vec3& scl = glm::vec3(1.0f))
        : position(pos), rotation(rot), scale(scl) {}

    glm::mat4 toMatrix() const {
        glm::mat4 model = glm::mat4(1.0f);
        model = glm::scale(model, scale);


        model = glm::rotate(model, glm::radians(rotation.x), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::rotate(model, glm::radians(rotation.z), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::rotate(model, glm::radians(rotation.y), glm::vec3(0.0f, 0.0f, 1.0f));
        model = glm::translate(model, position);

        return model;
    }
};

struct GLMesh {
private:
    GLuint VAO, VBO, EBO;
    std::vector<Vertex>vertices;
    std::vector<unsigned int> indices;

    void setupVertexData() {

        // create buffers/arrays
        glGenVertexArrays(1, &VAO);
        glGenBuffers(1, &VBO);
        glGenBuffers(1, &EBO);

        glBindVertexArray(VAO);

        // load data into vertex buffers
        glBindBuffer(GL_ARRAY_BUFFER, VBO);

        glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(Vertex), vertices.data(), GL_STATIC_DRAW);


        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), indices.data(), GL_STATIC_DRAW);


        // set the vertex attribute pointers:
        // vertex Positions
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, position));

        // vertex normals
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, texCoords));

        // vertex normals
        glEnableVertexAttribArray(2);
        glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, normals));


        glBindVertexArray(0);
    }

public:
    GLMesh() : VAO(0), VBO(0), EBO(0) {

    }

    GLMesh(const std::vector<Vertex>& verts, const std::vector<unsigned int>& inds)
        : vertices(verts), indices(inds), VAO(0), VBO(0), EBO(0) {
        setupVertexData();
    }

    ~GLMesh() {
        glDeleteVertexArrays(1, &VAO);
        glDeleteBuffers(1, &VBO);
        glDeleteBuffers(1, &EBO);
    }

    void bindVAO() const {
        glBindVertexArray(VAO);
    }

    size_t getIndicesCount() const {
        return indices.size();
    }
};

// Function Prototypes 
GLuint compileShader(GLenum type, const GLchar* source);
//void setupVertexData(GLuint& VAO, GLuint& VBO, GLuint& EBO, const std::vector<float>& vertices, const std::vector<unsigned int>& indices);
void createShaderProgram(GLuint& shaderProgram, const GLchar* vertexShaderSrc, const GLchar* fragmentShaderSource);
void checkShaderCompilation(GLuint shader);
void checkProgramLinking(GLuint program);
void initGLFW();
GLFWwindow* createWindow(int width, int height, const char* title);
bool isOpenGLError();
void mousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void mouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void initApplication(GLFWwindow*& window, GLuint& shaderProgram, AppContext& appContent);
void renderObject(GLMesh& mesh);
void renderScene(GLFWwindow* window, GLMesh& mesh, Transform& transform,
    GLuint& shaderProgram, AppContext& appContext, TextureHandler& texture, TextureHandler& overlayTexture,
    float blendFactor);
void processInput(GLFWwindow* window, AppContext* appContext, float deltaTime, TextureHandler& textureSamplerUV);
void setupProjectionAndMatrix(GLuint shaderProgram, AppContext& appContext);
void createTorus(std::vector<Vertex>& torusVertices, std::vector<unsigned int>& torusIndices, float outerRadius, float innerRadius, int numSlices, int numStacks);




// Shader sources
const char* vertexShaderSource = R"(
    #version 330 core
    layout (location = 0) in vec3 aPos;
    layout (location = 1) in vec2 textureCoordinate;
    layout (location = 2) in vec3 aNormal;

    out vec2 vertexTextureCoordinate;
    out vec3 Normal;
    out vec3 FragPos;

    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        FragPos = vec3(model * vec4(aPos, 1.0f));
        Normal = aNormal;
        vertexTextureCoordinate = textureCoordinate;
        gl_Position = projection * view * model * vec4(aPos, 1.0);
        
    }
)";

const char* fragmentShaderSource = R"(
    #version 330 core

    in vec2 vertexTextureCoordinate;
    in vec3 Normal;
    in vec3 FragPos;

    out vec4 FragColor;

    // Key light properties
    uniform vec3 keyLightPos;
    uniform vec3 keyLightColor; 
    uniform float keyLightIntensity;

    uniform vec3 viewPos;

    // Fill Light Properties
    uniform vec3 fillLightPos;
    uniform vec3 fillLightColor;
    uniform float fillLightIntensity;
    

    uniform sampler2D textureSamplerUV;
    uniform sampler2D textureSampler;
    uniform sampler2D overlayTexture;   // Overlay texture
    uniform float blendFactor;         // Blend factor for overlay
    uniform vec2 uvScale;
   
    

    void main()
    {
        
        vec3 norm = normalize(Normal);
        vec3 viewDir = normalize(viewPos - FragPos);

        // Ambient component
        float ambientStrength = 0.2;
        vec3 ambient = ambientStrength * vec3(1.0);

        // Key Light Calculations
        vec3 keyLightDir = normalize(keyLightPos - FragPos);
        float keyDiff  = max(dot(norm, keyLightDir), 0.0);
        vec3 keyDiffuse = keyDiff * keyLightColor * keyLightIntensity;

        float specularStrength = 0.5;
        vec3 keyReflectDir = reflect(-keyLightDir, norm);
        float keySpec = pow(max(dot(viewDir, keyReflectDir), 0.0), 32);
        vec3 keySpecular = specularStrength * keySpec * keyLightColor * keyLightIntensity;

        // Fill Light Calculations
        vec3 fillLightDir = normalize(fillLightPos - FragPos);
        float fillDiff  = max(dot(norm, fillLightDir), 0.0);
        vec3 fillDiffuse = fillDiff * fillLightColor * fillLightIntensity;

        
        vec3 fillReflectDir = reflect(-fillLightDir, norm);
        float fillSpec = pow(max(dot(viewDir, fillReflectDir), 0.0), 32);
        vec3 fillSpecular = specularStrength * fillSpec * fillLightColor * fillLightIntensity;

        // Combine the two lights
        vec3 lighting = ambient + keyDiffuse + keySpecular + fillDiffuse + fillSpecular;

        // texture Blending
        vec4 textureColor = texture(textureSampler, vertexTextureCoordinate);
        vec4 overlayColor = texture(overlayTexture, vertexTextureCoordinate);
        vec4 finalColor = mix(textureColor, overlayColor, blendFactor);

        FragColor = vec4(lighting * finalColor.rgb, finalColor.a);
    }
)";

glm::vec3 frontNormal = glm::vec3(0.0f, 0.0f, 1.0f);
glm::vec3 backNormal = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 leftNormal = glm::vec3(-1.0f, 0.0f, 0.0f);
glm::vec3 rightNormal = glm::vec3(1.0f, 0.0f, 0.0f);
glm::vec3 topNormal = glm::vec3(0.0f, 1.0f, 0.0f);
glm::vec3 bottomNormal = glm::vec3(0.0f, -1.0f, 0.0f);

std::vector<Vertex> cubeVertices = {

    // Front vertices
    Vertex(glm::vec3(-0.5f,  -0.5f,  0.5f), glm::vec2(0.0f, 0.0f), frontNormal),
    Vertex(glm::vec3( 0.5f,  -0.5f,  0.5f), glm::vec2(1.0f, 0.0f), frontNormal),
    Vertex(glm::vec3( 0.5f,   0.5f,  0.5f), glm::vec2(1.0f, 1.0f), frontNormal),
    Vertex(glm::vec3(-0.5f,   0.5f,  0.5f), glm::vec2(0.0f, 1.0f), frontNormal),

    
    // Back vertices
    Vertex(glm::vec3(-0.5f, -0.5f, -0.5f), glm::vec2(1.0f, 0.0f),  backNormal),
    Vertex(glm::vec3( 0.5f, -0.5f, -0.5f), glm::vec2(0.0f, 0.0f),  backNormal),
    Vertex(glm::vec3( 0.5f,  0.5f, -0.5f), glm::vec2(0.0f, 1.0f),  backNormal),
    Vertex(glm::vec3(-0.5f,  0.5f, -0.5f), glm::vec2(1.0f, 1.0f),  backNormal),

    // Left vertices                               
    Vertex(glm::vec3(-0.5f,  0.5f,  0.5f), glm::vec2(0.0f, 1.0f), leftNormal),
    Vertex(glm::vec3(-0.5f,  0.5f, -0.5f), glm::vec2(1.0f, 0.0f), leftNormal),
    Vertex(glm::vec3(-0.5f, -0.5f, -0.5f), glm::vec2(0.0f, 0.0f), leftNormal),
    Vertex(glm::vec3(-0.5f, -0.5f,  0.5f), glm::vec2(1.0f, 1.0f), leftNormal),

    // Right vertices
    Vertex(glm::vec3(0.5f,  0.5f,  0.5f), glm::vec2(0.0f, 1.0f), rightNormal),
    Vertex(glm::vec3(0.5f,  0.5f, -0.5f), glm::vec2(1.0f, 0.0f), rightNormal),
    Vertex(glm::vec3(0.5f, -0.5f, -0.5f), glm::vec2(0.0f, 0.0f), rightNormal),
    Vertex(glm::vec3(0.5f, -0.5f,  0.5f), glm::vec2(1.0f, 1.0f), rightNormal),
    
    // Top vertices
    Vertex(glm::vec3(-0.5f,  0.5f, -0.5f), glm::vec2(0.0f, 1.0f), topNormal),
    Vertex(glm::vec3(0.5f,  0.5f, -0.5f), glm::vec2(1.0f, 1.0f),  topNormal),
    Vertex(glm::vec3(0.5f,  0.5f,  0.5f), glm::vec2(1.0f, 0.0f), topNormal),
    Vertex(glm::vec3(-0.5f,  0.5f,  0.5f), glm::vec2(0.0f, 0.0f), topNormal),

    // Bottom vertices                          
     Vertex(glm::vec3(-0.5f, -0.5f, -0.5f), glm::vec2(0.0f, 1.0f), bottomNormal),
     Vertex(glm::vec3(0.5f, -0.5f, -0.5f), glm::vec2(1.0f, 1.0f), bottomNormal),
     Vertex(glm::vec3(0.5f, -0.5f,  0.5f), glm::vec2(1.0f, 0.0f), bottomNormal),
     Vertex(glm::vec3(-0.5f, -0.5f,  0.5f), glm::vec2(0.0f, 0.0f), bottomNormal),



};

std::vector<Vertex> cubehouseVertices = {
     // Front vertices
    Vertex(glm::vec3(-0.5f,  -0.5f,  0.5f), glm::vec2(0.0f, 0.0f), backNormal),
    Vertex(glm::vec3(0.5f,  -0.5f,  0.5f), glm::vec2(1.0f, 0.0f),  backNormal),
    Vertex(glm::vec3(0.5f,   0.5f,  0.5f), glm::vec2(1.0f, 1.0f),  backNormal),
    Vertex(glm::vec3(-0.5f,   0.5f,  0.5f), glm::vec2(0.0f, 1.0f), backNormal),


    // Back vertices
    Vertex(glm::vec3(-0.5f, -0.5f, -0.5f), glm::vec2(1.0f, 0.0f), frontNormal),
    Vertex(glm::vec3(0.5f, -0.5f, -0.5f), glm::vec2(0.0f, 0.0f),  frontNormal),
    Vertex(glm::vec3(0.5f,  0.5f, -0.5f), glm::vec2(0.0f, 1.0f),  frontNormal),
    Vertex(glm::vec3(-0.5f,  0.5f, -0.5f), glm::vec2(1.0f, 1.0f), frontNormal),

    // Left vertices                               
    Vertex(glm::vec3(-0.5f,  0.5f,  0.5f), glm::vec2(0.0f, 1.0f), rightNormal),
    Vertex(glm::vec3(-0.5f,  0.5f, -0.5f), glm::vec2(1.0f, 0.0f), rightNormal),
    Vertex(glm::vec3(-0.5f, -0.5f, -0.5f), glm::vec2(0.0f, 0.0f), rightNormal),
    Vertex(glm::vec3(-0.5f, -0.5f,  0.5f), glm::vec2(1.0f, 1.0f), rightNormal),

    // Right vertices
    Vertex(glm::vec3(0.5f,  0.5f,  0.5f), glm::vec2(0.0f, 1.0f), leftNormal),
    Vertex(glm::vec3(0.5f,  0.5f, -0.5f), glm::vec2(1.0f, 0.0f), leftNormal),
    Vertex(glm::vec3(0.5f, -0.5f, -0.5f), glm::vec2(0.0f, 0.0f), leftNormal),
    Vertex(glm::vec3(0.5f, -0.5f,  0.5f), glm::vec2(1.0f, 1.0f), leftNormal),

    // Top vertices
    Vertex(glm::vec3(-0.5f,  0.5f, -0.5f), glm::vec2(0.0f, 1.0f), bottomNormal),
    Vertex(glm::vec3(0.5f,  0.5f, -0.5f), glm::vec2(1.0f, 1.0f),  bottomNormal),
    Vertex(glm::vec3(0.5f,  0.5f,  0.5f), glm::vec2(1.0f, 0.0f),  bottomNormal),
    Vertex(glm::vec3(-0.5f,  0.5f,  0.5f), glm::vec2(0.0f, 0.0f), bottomNormal),

    // Bottom vertices                          
     Vertex(glm::vec3(-0.5f, -0.5f, -0.5f), glm::vec2(0.0f, 1.0f), topNormal),
     Vertex(glm::vec3(0.5f, -0.5f, -0.5f), glm::vec2(1.0f, 1.0f),  topNormal),
     Vertex(glm::vec3(0.5f, -0.5f,  0.5f), glm::vec2(1.0f, 0.0f),  topNormal),
     Vertex(glm::vec3(-0.5f, -0.5f,  0.5f), glm::vec2(0.0f, 0.0f), topNormal),



};




std::vector<unsigned int> cubeIndices = {

    
    // Base indices
    0, 1, 2, 2, 3, 0,


    // Back face
    4, 5, 6, 6, 7, 4,

    // Left face
    8, 9, 10, 10, 11, 8,

    // Right face
    12, 13, 14, 14, 15, 12,

    // Top face
    16, 17, 18, 16, 18, 19,

    // Bottom
    20, 21, 22, 22, 23, 20
    
    
};





std::vector<Vertex> cubeFrontVertices = {
    // Front vertices

    // Front vertices
    Vertex(glm::vec3(-0.5f,  -0.5f,  0.5f), glm::vec2(0.0f, 0.0f), frontNormal),
    Vertex(glm::vec3(0.5f,  -0.5f,  0.5f), glm::vec2(0.0f, 1.0f), frontNormal),
    Vertex(glm::vec3(0.5f,   0.5f,  0.5f), glm::vec2(1.0f, 1.0f), frontNormal),
    Vertex(glm::vec3(-0.5f,   0.5f,  0.5f), glm::vec2(1.0f, 0.0f), frontNormal)

};

std::vector<unsigned int> cubeFrontIndices = {
    // Base indices
    0, 1, 2,
    2, 3, 0
};

std::vector<Vertex> cubeBackVertices = {
    // Front vertices


    // Back vertices
    Vertex(glm::vec3(-0.5f, -0.5f, -0.5f), glm::vec2(0.0f, 0.0f), backNormal),
    Vertex(glm::vec3(0.5f, -0.5f, -0.5f), glm::vec2(1.0f, 0.0f), backNormal),
    Vertex(glm::vec3(0.5f,  0.5f, -0.5f), glm::vec2(1.0f, 1.0f), backNormal),
    Vertex(glm::vec3(-0.5f,  0.5f, -0.5f), glm::vec2(0.0f, 1.0f), backNormal)

};

std::vector<unsigned int> cubeBackIndices = {
    // Base indices
    0, 1, 2,
    2, 3, 0
};

std::vector<Vertex> cubeLeftVertices = {
    // Front vertices

     // Left vertices                               
    Vertex(glm::vec3(-0.5f,  0.5f,  0.5f), glm::vec2(0.0f, 0.0f), leftNormal),
    Vertex(glm::vec3(-0.5f,  0.5f, -0.5f), glm::vec2(1.0f, 0.0f), leftNormal),
    Vertex(glm::vec3(-0.5f, -0.5f, -0.5f), glm::vec2(1.0f, 1.0f), leftNormal),
    Vertex(glm::vec3(-0.5f, -0.5f,  0.5f), glm::vec2(0.0f, 1.0f), leftNormal)


};

std::vector<Vertex> bookshelfLeftVertices = {
    // Front vertices

     // Left vertices                               
    Vertex(glm::vec3(-0.5f,  0.5f,  0.5f), glm::vec2(0.0f, 0.0f), rightNormal),
    Vertex(glm::vec3(-0.5f,  0.5f, -0.5f), glm::vec2(1.0f, 0.0f), rightNormal),
    Vertex(glm::vec3(-0.5f, -0.5f, -0.5f), glm::vec2(1.0f, 1.0f), rightNormal),
    Vertex(glm::vec3(-0.5f, -0.5f,  0.5f), glm::vec2(0.0f, 1.0f), rightNormal)


};


std::vector<unsigned int> cubeLeftIndices = {
    // Base indices
    0, 1, 2,
    2, 3, 0
};

std::vector<Vertex> cubeRightVertices = {
    // Front vertices

        // Right vertices
    Vertex(glm::vec3(0.5f,  0.5f,  0.5f), glm::vec2(0.0f, 0.0f), rightNormal),
    Vertex(glm::vec3(0.5f,  0.5f, -0.5f), glm::vec2(1.0f, 0.0f), rightNormal),
    Vertex(glm::vec3(0.5f, -0.5f, -0.5f), glm::vec2(1.0f, 1.0f), rightNormal),
    Vertex(glm::vec3(0.5f, -0.5f,  0.5f), glm::vec2(0.0f, 1.0f), rightNormal)

};

std::vector<unsigned int> cubeRightIndices = {
    // Base indices
    0, 1, 2,
    2, 3, 0
};

std::vector<Vertex> cubeTopVertices = {
    // Front vertices

      // Top vertices
    Vertex(glm::vec3(-0.5f,  0.5f, -0.5f), glm::vec2(0.0f, 0.0f), topNormal),
    Vertex(glm::vec3(0.5f,  0.5f, -0.5f), glm::vec2(1.0f, 0.0f), topNormal),
    Vertex(glm::vec3(0.5f,  0.5f,  0.5f), glm::vec2(1.0f, 1.0f), topNormal),
    Vertex(glm::vec3(-0.5f,  0.5f,  0.5f), glm::vec2(0.0f, 1.0f), topNormal)

};

std::vector<unsigned int> cubeTopIndices = {
    // 
    0, 1, 2,
    2, 3, 0
};

std::vector<Vertex> cubeBottomVertices = {
    // Front vertices

        // Bottom vertices                          
     Vertex(glm::vec3(-0.5f, -0.5f, -0.5f), glm::vec2(0.0f, 1.0f), bottomNormal),
     Vertex(glm::vec3(0.5f, -0.5f, -0.5f),  glm::vec2(1.0f, 0.0f), bottomNormal),
     Vertex(glm::vec3(0.5f, -0.5f,  0.5f),  glm::vec2(0.0f, 0.0f), bottomNormal),
     Vertex(glm::vec3(-0.5f, -0.5f,  0.5f), glm::vec2(1.0f, 1.0f), bottomNormal)

};

std::vector<unsigned int> cubeBottomIndices = {
    // Base indices
    0, 1, 2,
    2, 3, 0
};

std::vector<unsigned int> pyramidIndices = {

    // Base indices - drawing the base as two triangles
    0, 1, 2,
    3, 4, 5,
    6, 7, 8,
    9, 10, 11,

    12, 13, 14,
    12, 14, 15

};

std::vector<Vertex> planeVertices = {

    // First Triangle
    Vertex(glm::vec3(-1.0f, -1.0f,  -1.0f),  glm::vec2(0.0f, 0.0f), topNormal),
    Vertex(glm::vec3(-1.0f, -1.0f,   1.0f),  glm::vec2(1.0f, 0.0f), topNormal),
    Vertex(glm::vec3(1.0f, -1.0f,   1.0f),  glm::vec2(1.0f, 1.0f), topNormal),

    Vertex(glm::vec3(1.0f,  -1.0f,  -1.0f),  glm::vec2(0.0f, 1.0f), topNormal)


};

std::vector<unsigned int> planeIndices = {
    // Base indices
     0, 1, 2,
     0, 2, 3
};

// Function to check program linking errors
void checkProgramLinking(GLuint program) {
    GLint success;
    GLchar infoLog[512];
    glGetProgramiv(program, GL_LINK_STATUS, &success);
    if (!success) {
        glGetProgramInfoLog(program, 512, NULL, infoLog);
        std::cerr << "Program Linking Failed\n" << infoLog << std::endl;
    }

}

void initGLFW()
{
    // Initialize GLFW
    if (!glfwInit())
    {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        exit(-1);
    }

    // Configure GLFW
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

}

GLFWwindow* createWindow(int width, int height, const char* title)
{
    // Create a GLFW window
    GLFWwindow* window = glfwCreateWindow(width, height, title, nullptr, nullptr);
    if (window)
    {
        // Make the OpenGL context current
        glfwMakeContextCurrent(window);

        // Initialize GLEW
        if (glewInit() != GLEW_OK)
        {
            std::cerr << "Failed to initialize GLEW" << std::endl;
            glfwDestroyWindow(window);
            window = nullptr;
        }

    }




    return window;
}

bool isOpenGLError()
{
    bool foundError = false;
    int glError = glGetError();

    while (glError != GL_NO_ERROR) {
        std::cout << "glError: " << glError << std::endl;
        foundError = true;
        glError = glGetError();

    }
    return foundError;
}

GLuint compileShader(GLenum type, const GLchar* source)
{
    GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, nullptr);
    glCompileShader(shader);
    checkShaderCompilation(shader);
    return shader;
}

void createShaderProgram(GLuint& shaderProgram, const GLchar* vertexShaderSource, const GLchar* fragmentShaderSource)
{
    GLuint vertexShader = compileShader(GL_VERTEX_SHADER, vertexShaderSource);
    GLuint fragmentShader = compileShader(GL_FRAGMENT_SHADER, fragmentShaderSource);

    shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);
    checkProgramLinking(shaderProgram);

    // Delete the shader objects
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);


}

// Function to check shader compliation errors
void checkShaderCompilation(GLuint shader) {
    GLint success;
    GLchar infoLog[512];
    glGetShaderiv(shader, GL_LINK_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(shader, 512, NULL, infoLog);
        std::cerr << "Shader Compilation Failed\n" << infoLog << std::endl;
    }

}

void initApplication(GLFWwindow*& window, GLuint& shaderProgram, AppContext& appContext)
{
    // Initialize GLFW
    initGLFW();

    // Create a GLFW window
    window = createWindow(800, 600, "Debynyhan");
    if (!window)
    {
        std::cerr << "Failed to creat GLFW window" << std::endl;
        //glfwTerminate();
        exit(-1);
    }

    if (isOpenGLError()) {
        std::cerr << "OpenGL error occured after creating window " << std::endl;
    }
    createShaderProgram(shaderProgram, vertexShaderSource, fragmentShaderSource);



    glfwSetWindowUserPointer(window, &appContext);
    glfwSetCursorPosCallback(window, mousePositionCallback);
    glfwSetScrollCallback(window, mouseScrollCallback);


}

void mousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    AppContext* appContext = static_cast<AppContext*>(glfwGetWindowUserPointer(window));

    // Update the mouse position
    if (appContext && appContext->camera && appContext->mouseHandler) {
        appContext->mouseHandler->updateMousePosition(window, *appContext->camera, 0.0f);
    }

}

void mouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    AppContext* appContext = static_cast<AppContext*>(glfwGetWindowUserPointer(window));

    // Update the mouse position
    if (appContext && appContext->camera) {

        float scrollSpeedAdjustmentFactor = 0.1f;

        // Adjust camera speed based on yoffset
        float speedChange = yoffset * scrollSpeedAdjustmentFactor;
        appContext->camera->AdjustSpeed(speedChange);
    }

}

void processInput(GLFWwindow* window, AppContext* appContext, float deltaTime, TextureHandler& textureToScale)
{
    static const float cameraSpeed = 0.5f;
    static bool pKeyPressed = false;

    Camera* camera = appContext->camera;


    // Toggle between perspective
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS && !pKeyPressed) {
        appContext->isPerspective = !appContext->isPerspective;
        pKeyPressed = true;
    }

    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_RELEASE) {
        pKeyPressed = false;
    }
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
        glfwSetWindowShouldClose(window, true);
    }

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
        camera->ProcessKeyboard(FORWARD, deltaTime);
    }

    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
        camera->ProcessKeyboard(BACKWARD, deltaTime);
    }


    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
        camera->ProcessKeyboard(LEFT, deltaTime);
    }


    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
        camera->ProcessKeyboard(RIGHT, deltaTime);
    }
    
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
        camera->ProcessKeyboard(UP, deltaTime);
    }
    

    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
        camera->ProcessKeyboard(DOWN, deltaTime);
    }

    if (glfwGetKey(window, GLFW_KEY_RIGHT_BRACKET) == GLFW_PRESS) {

        textureToScale.scaleTexture(1.1f);
    }

    if (glfwGetKey(window, GLFW_KEY_LEFT_BRACKET) == GLFW_PRESS) {

        textureToScale.scaleTexture(0.9f);
    }
}

void setupProjectionAndMatrix(GLuint shaderProgram, AppContext& appContext)
{
    // Set the perspective projection matrix
    float aspectRatio = 800.0f / 600.0f;
    glm::mat4 projection;



    if (appContext.isPerspective) {
        // Calculate and set the perspective camera's view matrix.
        projection = glm::perspective(glm::radians(50.0f), aspectRatio, 0.1f, 100.0f);
    }
    else {
        float orthoSize = 10.0f;
        // Calculate and set the perspective camera's view matrix.
        projection = glm::ortho(-orthoSize, orthoSize, -orthoSize, orthoSize, 0.1f, 100.0f);
    }

    GLint projectionLoc = glGetUniformLocation(shaderProgram, "projection");
    glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projection));


}

void createTorus(std::vector<Vertex>& torusVertices, std::vector<unsigned int>& torusIndices, float outerRadius, float innerRadius, int numSlices, int numStacks)
{
    // Generate torus vertices
    for (int stack = 0; stack <= numStacks; ++stack) {
        float stackAngle = 2.0f * 3.142 * stack / numStacks; // Covering full 360 degress
        for (int slice = 0; slice <= numSlices; ++slice) {
            float sliceAngle = 2.0f * 3.142 * slice / numSlices; // Covering full 360 degress for numSlices
            float u = (float)slice / numSlices;
            float v = (float)stack / numStacks; 

            // Position
            float x = cos(stackAngle) * (outerRadius + innerRadius * cos(sliceAngle));
            float y = sin(stackAngle) * (outerRadius + innerRadius * cos(sliceAngle));
            float z = innerRadius * sin(sliceAngle);

            // Normal
            glm::vec3 centerOfTube = glm::vec3(cos(stackAngle) * outerRadius, sin(stackAngle) * outerRadius, 0);
            glm::vec3 position = glm::vec3(x, y, z);
            glm::vec3 normal = glm::normalize(position - centerOfTube);


            torusVertices.emplace_back(position, glm::vec2(u, v), normal);
        }
    }

    // Generate torus Indices
    for (int stack = 0; stack < numStacks; ++stack) {
        for (int slice = 0; slice < numSlices; ++slice) {
            int first = (stack * (numSlices + 1)) + slice;
            int second = first + numSlices + 1;

            torusIndices.push_back(first);
            torusIndices.push_back(second);
            torusIndices.push_back(first + 1);

            torusIndices.push_back(second);
            torusIndices.push_back(second + 1);
            torusIndices.push_back(first + 1);


        }
    }
}




void renderObject(GLMesh& mesh)
{
    // Bind the mesh's VAO to set it as the current one OpenGL uses for rendering
    mesh.bindVAO();

    // Execute the draw call using the bound VAO. This tells OpenGL to render triangles using
    // the indices in the EBO of the mesh. The number of indices is determined
    // by the getIndicesCount method, and GL_UNSIGNED_INT specifies the format of the indices
    glDrawElements(GL_TRIANGLES, static_cast<GLsizei>(mesh.getIndicesCount()), GL_UNSIGNED_INT, 0);

    // Unbind the VAO to prevent accidental modification of the VAO after the call
    // This is a safety practice and not strictly necessary in every context
    glBindVertexArray(0);
}


void renderScene(GLFWwindow* window, GLMesh& mesh, Transform& transform,
    GLuint& shaderProgram, AppContext& appContext, TextureHandler& texture, TextureHandler& overlayTexture,
    float blendFactor)
{
    // Enable OpendGL's depth testing to handle overlapping obects correctly
    glEnable(GL_DEPTH_TEST);

    // Use the specified shader program for rendering
    glUseProgram(shaderProgram);


    // Calculate and set the view matrix using the camera's view matrix.
    glm::mat4 view = appContext.camera->GetViewMatrix();
    GLint viewLoc = glGetUniformLocation(shaderProgram, "view");
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));


    // Calculate and set the model matrix based on the transform of the object.
    glm::mat4 model = transform.toMatrix();
    GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Set the camera/view Positio in the shader
    glUniform3fv(glGetUniformLocation(shaderProgram, "viewPos"), 1, glm::value_ptr(appContext.camera->Position));

    // Set key light properties
    glUniform3f(glGetUniformLocation(shaderProgram, "keyLightPos"), 0.0f, 10.0f, 3.0f);
    glUniform3f(glGetUniformLocation(shaderProgram, "keyLightColor"), 1.0f, 1.0f, 0.3f);
    glUniform1f(glGetUniformLocation(shaderProgram, "keyLightIntensity"), 0.1f);

    // Set key light properties
    glUniform3f(glGetUniformLocation(shaderProgram, "fillLightPos"), -0.5f, 6.5f, 6.0f);
    glUniform3f(glGetUniformLocation(shaderProgram, "fillLightColor"), 1.0f, 1.0f, 1.0f);
    glUniform1f(glGetUniformLocation(shaderProgram, "fillLightIntensity"), 0.9f);

    // Activate and bind textures
    texture.activateAndBind(GL_TEXTURE0);
    glUniform1i(glGetUniformLocation(shaderProgram, "textureSampler"), 0);

    texture.activateAndBind(GL_TEXTURE1);
    glUniform1i(glGetUniformLocation(shaderProgram, "textureSamplerUV"), 1);

    overlayTexture.activateAndBind(GL_TEXTURE2);
    glUniform1i(glGetUniformLocation(shaderProgram, "overlayTexture"), 2);

    // Set the texture sampler to use texture unit 0
    glUniform1f(glGetUniformLocation(shaderProgram, "blendFactor"), blendFactor);

    texture.setScaleUniform(shaderProgram, "uvScale");

    // Render the mesh
    renderObject(mesh);


}



int main()
{
    GLFWwindow* window;
    GLuint shaderProgram;
   

    // SetUp Meshes
    float height = 2.0f;
    float radius = 1.0f;
    int sides = 32;

    // Torus Dimension
    float outerRadius = 0.3f;
    float innerRadius = 0.2f;
    int numSlices = 32;
    int numStacks = 16;


    CylinderParams cylinder(height, radius, sides);
    
    
    // Initialize camera and mouseHandler
    MouseHandler mouseHandler;
    Camera camera(glm::vec3(0.0f, 3.0f, 6.0f), glm::vec3(0.0f, 1.0f, 0.0f), YAW, -22.0f);

    
    // Variable to track the time of the last frame
    float lastFrame = 0.0f;

    // Flag to indicate if the view mode has changed
    bool viewModeChanged = true;

    // Create appContext and set it camera and mouseHandler
    AppContext appContext = { &camera, &mouseHandler };


    try {

        initApplication(window, shaderProgram,  appContext);

        
        TextureHandler textureSamplerUV("..\\..\\woodFine.jpg");
        TextureHandler textureSamplerUV1("..\\..\\plaster2.jpg");
        TextureHandler frontTexture("..\\..\\blue.png");
        TextureHandler backTexture("..\\..\\orange.png");
        TextureHandler leftTexture("..\\..\\white.png");
        TextureHandler rightTexture("..\\..\\yellow.png");
        TextureHandler topTexture("..\\..\\red.png");
        TextureHandler bottomTexture("..\\..\\green.png");
        TextureHandler bookshelfTexture("..\\..\\bookshelf.png");
        TextureHandler pyramidTexture("..\\..\\brick.jpg");
        TextureHandler overlayTexture("..\\..\\woodFine.jpg");
        TextureHandler radioTexture("..\\..\\jbl2go.png");
        TextureHandler tabletTexture("..\\..\\tab.png");
        TextureHandler penTexture("..\\..\\penT.png");
        



        float blendFactor = 0.1f;

  
        //GLMesh lightCubeMesh(cubeVertices, cubeIndices);
        std::vector<Vertex> torusVertices;
        std::vector<unsigned int> torusIndices;
        createTorus(torusVertices, torusIndices, outerRadius, innerRadius, numSlices, numStacks);


        GLMesh penholderMesh(torusVertices, torusIndices);
        GLMesh cylinderMesh(cylinder.vertices, cylinder.indices);
        GLMesh planeMesh(planeVertices, planeIndices);
        GLMesh cubeMesh(cubeVertices, cubeIndices);
        GLMesh houseMesh(cubehouseVertices, cubeIndices);
        GLMesh bookshelf(cubeVertices, cubeIndices);
        GLMesh cubeFrontFace(cubeFrontVertices, cubeFrontIndices);
        GLMesh cubeBackFace(cubeBackVertices, cubeBackIndices);
        GLMesh cubeLeftFace(cubeLeftVertices, cubeLeftIndices);
        GLMesh bookshelfLeftFace(bookshelfLeftVertices, cubeLeftIndices);
        GLMesh cubeRightFace(cubeRightVertices, cubeRightIndices);
        GLMesh cubeTopFace(cubeTopVertices, cubeTopIndices);
        GLMesh cubeBottomFace(cubeBottomVertices, cubeBottomIndices);
        GLMesh radio(cubeVertices, cubeIndices);
        GLMesh tablet(cubeVertices, cubeIndices);
        
        
        Transform tabletTransform = Transform(glm::vec3(0.0f, -10.0f, 0.5f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(5.0f, 0.1f, 2.0f));
        Transform radioTransform = Transform(glm::vec3(-0.25f, -0.4f, -3.5f), glm::vec3(0.0f), glm::vec3(1.4f, 1.4f, 0.3f));
        Transform bookshelfLeftTransform = Transform(glm::vec3(0.003f, 0.0f, -4.6f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(13.0f, 13.0f, 3.0f));
        Transform cubeFrontTransform = Transform(glm::vec3(2.0f, -0.5f, -1.25f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(1.2f));
        Transform cubeBackTransform = Transform(glm::vec3(2.0f, -0.5f, -0.75f),  glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(1.2f));
        Transform cubeRightTransform = Transform(glm::vec3(2.0f, -0.5f, -2.0f),  glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(1.2f, 1.2f, 0.6f));
        Transform cubeLeftTransform = Transform(glm::vec3(2.0f, -0.5f, -2.0f),   glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(1.2f, 1.2f, 0.6f));
        Transform cubeTopTransform = Transform(glm::vec3(2.0f, -0.5f, -2.0f),    glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(1.2f, 1.2f, 0.6f));
        Transform cubeBottomTransform = Transform(glm::vec3(2.0f, -0.5f, -2.0f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(1.2f, 1.2f, 0.6f));
        Transform planeTransform = Transform(glm::vec3(0.0f, -0.2f, 0.2f), glm::vec3(0.0f), glm::vec3(10.0f, 1.0f, 4.0f));
        Transform cubeTransform = Transform(glm::vec3(-0.25f, 0.35f, -0.2f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(45.0f, 40.0f, 25.0f));
        Transform houseTransform = Transform(glm::vec3(-0.25f, 0.35f, -0.2f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(45.0f, 40.0f, 25.0f));
        Transform bookshelfTransform = Transform(glm::vec3(-1.0f, 0.02f, -4.7f), glm::vec3(0.0f), glm::vec3(13.0f, 13.0f, 3.0f));
        Transform cylinderTransform = Transform(glm::vec3(-29.5f, 0.0f, -17.0f), glm::vec3(0.0f), glm::vec3(0.1f, 1.0f, 0.1f));
        Transform penholderTransform = Transform(glm::vec3(-3.0f, -1.8f, 1.1f), glm::vec3(90.0f, 0.0f, 0.0f), glm::vec3(1.0f));
        
        
        // Store the initial state of isPerspective
        bool previousIsPerspective = appContext.isPerspective;


        // Main render loop that runs until the window is closed
        while (!glfwWindowShouldClose(window))
        {
            // Calculate the time elapsed since the last frame
            double currentFrame = glfwGetTime();
            float deltaTime = static_cast<float>(currentFrame - lastFrame);
            lastFrame = currentFrame;

            // Process user input
            processInput(window, &appContext, deltaTime, textureSamplerUV);

            // Clear the screen to prepare for the new frame
            glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

            // Check if view mode changed for the next frame
            if (appContext.isPerspective != previousIsPerspective) {
                viewModeChanged = true;
                previousIsPerspective = appContext.isPerspective;
            }



            

           
            
            renderScene(window, cubeFrontFace, cubeFrontTransform, shaderProgram, appContext, frontTexture, overlayTexture, blendFactor);

            renderScene(window, planeMesh, planeTransform, shaderProgram, appContext, textureSamplerUV, textureSamplerUV, blendFactor);

            renderScene(window, cubeBackFace, cubeBackTransform, shaderProgram, appContext, backTexture, overlayTexture, blendFactor);

            renderScene(window, cubeLeftFace, cubeLeftTransform, shaderProgram, appContext, leftTexture, overlayTexture, blendFactor);

            renderScene(window, cubeRightFace, cubeRightTransform, shaderProgram, appContext, rightTexture, overlayTexture, blendFactor);

            renderScene(window, cubeTopFace, cubeTopTransform, shaderProgram, appContext, topTexture, overlayTexture, blendFactor);

            renderScene(window, cubeBottomFace, cubeBottomTransform, shaderProgram, appContext, bottomTexture, overlayTexture, blendFactor);

            renderScene(window, houseMesh, houseTransform, shaderProgram, appContext, textureSamplerUV1, textureSamplerUV1, blendFactor);

            renderScene(window, bookshelf, bookshelfTransform, shaderProgram, appContext, bookshelfTexture, bookshelfTexture, blendFactor);

            renderScene(window, bookshelfLeftFace, bookshelfLeftTransform, shaderProgram, appContext, textureSamplerUV, textureSamplerUV, blendFactor);

            renderScene(window, cylinderMesh, cylinderTransform, shaderProgram, appContext, penTexture, penTexture, blendFactor);
            
            renderScene(window, radio, radioTransform, shaderProgram, appContext, radioTexture, radioTexture, blendFactor);

            renderScene(window, tablet, tabletTransform, shaderProgram, appContext, tabletTexture, tabletTexture, blendFactor);

            renderScene(window, penholderMesh, penholderTransform, shaderProgram, appContext, tabletTexture, tabletTexture, blendFactor);
            
           
            
            // Swap the front and back buffers (double buffering) and poll for events
            glfwSwapBuffers(window);
            glfwPollEvents();


            // If view mode changed, update projection matrix
            if (viewModeChanged) {
                // Setup the projection matrix for the shader
                setupProjectionAndMatrix(shaderProgram, appContext);
                viewModeChanged = false;
            }

        }


        

    }

    catch (const std::exception& e) {

        std::cerr << "Exception caught: " << e.what() << std::endl;

        glDeleteProgram(shaderProgram);

        return -1;
    }

    glDeleteProgram(shaderProgram);

    glfwTerminate();

    return 0;
}

